@extends('layouts.app')

@section('content')

<style>
    /* =========================================================
       EDUKASI UMUM
    ========================================================= */

    .edu-page {
        --green: #176b4d;
        --green-dark: #124f39;
        --green-light: #23805d;
        --green-soft: #eaf5ef;

        --red: #8d2634;
        --red-dark: #721d29;
        --red-soft: #faeeee;

        --text: #252525;
        --muted: #6f7672;
        --line: #e2e7e4;
        --white: #fff;
        --bg: #f7f9f8;

        color: var(--text);
        background: var(--bg);
        padding-bottom: 80px;
    }

    .edu-page *,
    .edu-page *::before,
    .edu-page *::after {
        box-sizing: border-box;
    }

    .edu-container {
        width: min(1180px, calc(100% - 40px));
        margin: auto;
    }


    /* =========================================================
       HERO
    ========================================================= */

    .edu-hero {
        position: relative;
        overflow: hidden;
        padding: 80px 0;
        color: #fff;
        background:
            linear-gradient(
                120deg,
                rgba(18, 79, 57, .98),
                rgba(23, 107, 77, .94)
            );
    }

    .edu-hero::after {
        content: "";
        position: absolute;
        width: 390px;
        height: 390px;
        right: -150px;
        top: -170px;
        border-radius: 50%;
        border: 70px solid rgba(255,255,255,.05);
    }

    .edu-hero-content {
        position: relative;
        z-index: 2;
        max-width: 760px;
    }

    .edu-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 9px;
        margin-bottom: 18px;
        font-size: 12px;
        font-weight: 800;
        letter-spacing: 1.7px;
        text-transform: uppercase;
        color: #d8eee3;
    }

    .edu-eyebrow::before {
        content: "";
        width: 30px;
        height: 2px;
        background: #fff;
    }

    .edu-hero h1 {
        margin: 0 0 18px;
        font-size: clamp(38px, 5vw, 62px);
        line-height: 1.05;
        font-weight: 800;
        letter-spacing: -1.5px;
    }

    .edu-hero p {
        max-width: 690px;
        margin: 0;
        color: rgba(255,255,255,.84);
        font-size: 17px;
        line-height: 1.8;
    }


    /* =========================================================
       INTRO
    ========================================================= */

    .edu-intro {
        padding: 55px 0 35px;
    }

    .edu-intro-box {
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 30px;
        align-items: center;
        padding: 30px 34px;
        background: #fff;
        border: 1px solid var(--line);
        border-radius: 8px;
    }

    .edu-intro-box h2 {
        margin: 0 0 8px;
        color: var(--green-dark);
        font-size: 25px;
    }

    .edu-intro-box p {
        margin: 0;
        color: var(--muted);
        line-height: 1.75;
    }

    .edu-intro-number {
        width: 68px;
        height: 68px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        background: var(--green-soft);
        color: var(--green);
        font-size: 24px;
        font-weight: 800;
    }


    /* =========================================================
       HEADING
    ========================================================= */

    .section-heading {
        margin-bottom: 30px;
    }

    .section-heading small,
    .magang-section-title small {
        display: block;
        margin-bottom: 8px;
        color: var(--red);
        font-size: 11px;
        font-weight: 800;
        letter-spacing: 1.6px;
        text-transform: uppercase;
    }

    .section-heading h2 {
        margin: 0 0 10px;
        color: var(--green-dark);
        font-size: clamp(30px, 4vw, 42px);
        line-height: 1.15;
    }

    .section-heading p {
        max-width: 700px;
        margin: 0;
        color: var(--muted);
        line-height: 1.75;
    }


    /* =========================================================
       MATERI UTAMA
    ========================================================= */

    .materi-section {
        padding: 20px 0 70px;
    }

    .materi-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
    }

    .materi-card {
        position: relative;
        min-height: 300px;
        padding: 30px;
        overflow: hidden;
        cursor: pointer;
        background: #fff;
        border: 1px solid var(--line);
        border-radius: 8px;
        transition: .25s ease;
    }

    .materi-card:hover {
        transform: translateY(-6px);
        border-color: rgba(23,107,77,.35);
        box-shadow: 0 18px 40px rgba(25,55,43,.10);
    }

    .materi-number {
        margin-bottom: 45px;
        color: var(--red);
        font-size: 12px;
        font-weight: 800;
        letter-spacing: 1.5px;
    }

    .materi-card h3 {
        margin: 0 0 12px;
        color: var(--green-dark);
        font-size: 25px;
    }

    .materi-card p {
        margin: 0;
        color: var(--muted);
        font-size: 14px;
        line-height: 1.7;
    }

    .materi-arrow {
        position: absolute;
        right: 25px;
        bottom: 24px;
        width: 42px;
        height: 42px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        background: var(--green-soft);
        color: var(--green);
        transition: .25s ease;
    }

    .materi-card:hover .materi-arrow {
        background: var(--green);
        color: #fff;
        transform: translateX(4px);
    }


    /* =========================================================
       DETAIL MATERI
    ========================================================= */

    .materi-detail {
        display: none;
        padding: 30px 0 80px;
        animation: detailFade .35s ease;
    }

    .materi-detail.active {
        display: block;
    }

    @keyframes detailFade {
        from {
            opacity: 0;
            transform: translateY(15px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .back-materi {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 25px;
        padding: 8px 0;
        border: 0;
        background: transparent;
        color: var(--green);
        font-size: 14px;
        font-weight: 700;
        cursor: pointer;
    }

    .back-materi:hover {
        color: var(--red);
    }


    /* =========================================================
       HERO MAGANG
    ========================================================= */

    .magang-hero {
        position: relative;
        overflow: hidden;
        margin-bottom: 65px;
        padding: 55px;
        border-radius: 10px;
        background: var(--green-dark);
        color: #fff;
    }

    .magang-hero::after {
        content: "";
        position: absolute;
        right: -120px;
        bottom: -180px;
        width: 350px;
        height: 350px;
        border: 70px solid rgba(255,255,255,.05);
        border-radius: 50%;
    }

    .magang-hero-content {
        position: relative;
        z-index: 2;
        max-width: 760px;
    }

    .magang-hero small {
        display: block;
        margin-bottom: 15px;
        color: #cce9dc;
        font-size: 12px;
        font-weight: 800;
        letter-spacing: 1.5px;
        text-transform: uppercase;
    }

    .magang-hero h2 {
        margin: 0 0 18px;
        font-size: clamp(32px, 5vw, 53px);
        line-height: 1.08;
    }

    .magang-hero p {
        max-width: 690px;
        margin: 0;
        color: rgba(255,255,255,.82);
        line-height: 1.8;
    }

    .magang-explore {
        display: inline-flex;
        align-items: center;
        gap: 9px;
        margin-top: 28px;
        padding: 13px 21px;
        border: 0;
        border-radius: 5px;
        background: #fff;
        color: var(--green-dark);
        font-size: 14px;
        font-weight: 800;
        cursor: pointer;
        transition: .2s ease;
    }

    .magang-explore:hover {
        background: var(--red);
        color: #fff;
    }


    /* =========================================================
       SECTION MAGANG
    ========================================================= */

    .magang-section {
        margin-bottom: 75px;
    }

    .magang-section-title {
        max-width: 720px;
        margin-bottom: 28px;
    }

    .magang-section-title h3 {
        margin: 8px 0 10px;
        color: var(--green-dark);
        font-size: 32px;
    }

    .magang-section-title p {
        margin: 0;
        color: var(--muted);
        line-height: 1.75;
    }


    /* =========================================================
       MANFAAT
    ========================================================= */

    .benefit-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 16px;
    }

    .benefit-card {
        padding: 25px;
        border: 1px solid var(--line);
        border-radius: 7px;
        background: #fff;
    }

    .benefit-icon {
        width: 46px;
        height: 46px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 18px;
        border-radius: 5px;
        background: var(--green-soft);
        color: var(--green);
        font-size: 20px;
    }

    .benefit-card h4 {
        margin: 0 0 8px;
        color: var(--green-dark);
        font-size: 17px;
    }

    .benefit-card p {
        margin: 0;
        color: var(--muted);
        font-size: 13px;
        line-height: 1.7;
    }


    /* =========================================================
       JURUSAN + FOTO
    ========================================================= */

    .jurusan-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
    }

    .jurusan-card {
        overflow: hidden;
        min-height: 300px;
        border: 1px solid var(--line);
        border-radius: 8px;
        background: #fff;
        cursor: pointer;
        transition: .25s ease;
    }

    .jurusan-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 18px 38px rgba(25,55,43,.12);
    }

    .jurusan-image {
        width: 100%;
        height: 185px;
        overflow: hidden;
        background: #dfe8e3;
    }

    .jurusan-image img {
        width: 100%;
        height: 100%;
        display: block;
        object-fit: cover;
        transition: transform .4s ease;
    }

    .jurusan-card:hover .jurusan-image img {
        transform: scale(1.05);
    }

    .jurusan-content {
        padding: 20px;
    }

    .jurusan-content small {
        display: block;
        margin-bottom: 6px;
        color: var(--red);
        font-size: 10px;
        font-weight: 800;
        letter-spacing: 1.2px;
        text-transform: uppercase;
    }

    .jurusan-content h4 {
        margin: 0 0 7px;
        color: var(--green-dark);
        font-size: 18px;
    }

    .jurusan-content p {
        margin: 0;
        color: var(--muted);
        font-size: 13px;
        line-height: 1.6;
    }


    /* =========================================================
       DETAIL JURUSAN
    ========================================================= */

    .jurusan-detail {
        display: none;
        margin-top: 25px;
        padding: 28px;
        border: 1px solid var(--line);
        border-radius: 8px;
        background: #fff;
        animation: detailFade .3s ease;
    }

    .jurusan-detail.active {
        display: block;
    }

    .jurusan-detail-inner {
        display: grid;
        grid-template-columns: 260px 1fr;
        gap: 28px;
        align-items: center;
    }

    .jurusan-detail-image {
        width: 100%;
        height: 190px;
        overflow: hidden;
        border-radius: 7px;
    }

    .jurusan-detail-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .jurusan-detail small {
        color: var(--red);
        font-size: 11px;
        font-weight: 800;
        letter-spacing: 1.2px;
        text-transform: uppercase;
    }

    .jurusan-detail h4 {
        margin: 8px 0 10px;
        color: var(--green-dark);
        font-size: 25px;
    }

    .jurusan-detail p {
        margin: 0;
        color: var(--muted);
        line-height: 1.8;
    }

    .close-jurusan {
        margin-top: 18px;
        padding: 9px 15px;
        border: 0;
        border-radius: 5px;
        background: var(--green-soft);
        color: var(--green-dark);
        font-weight: 700;
        cursor: pointer;
    }


    /* =========================================================
       PENGALAMAN MAGANG - FOTO SLIDER
    ========================================================= */

    .experience-slider {
        position: relative;
    }

    .experience-controls {
        display: flex;
        justify-content: flex-end;
        gap: 8px;
        margin-bottom: 15px;
    }

    .experience-control {
        width: 42px;
        height: 42px;
        display: flex;
        align-items: center;
        justify-content: center;
        border: 1px solid var(--line);
        border-radius: 50%;
        background: #fff;
        color: var(--green-dark);
        cursor: pointer;
        transition: .2s ease;
    }

    .experience-control:hover {
        border-color: var(--green);
        background: var(--green);
        color: #fff;
    }

    .experience-track {
        display: flex;
        gap: 22px;
        overflow-x: auto;
        padding: 5px 3px 20px;
        scroll-behavior: smooth;
        scroll-snap-type: x mandatory;
        scrollbar-width: none;
    }

    .experience-track::-webkit-scrollbar {
        display: none;
    }

    .experience-card {
        flex: 0 0 calc(50% - 11px);
        min-width: 0;
        overflow: hidden;
        scroll-snap-align: start;
        border: 1px solid var(--line);
        border-radius: 10px;
        background: #fff;
    }

    .experience-card-image {
        width: 100%;
        height: 270px;
        overflow: hidden;
        background: #dfe7e2;
    }

    .experience-card-image img {
        width: 100%;
        height: 100%;
        display: block;
        object-fit: cover;
        transition: transform .4s ease;
    }

    .experience-card:hover .experience-card-image img {
        transform: scale(1.04);
    }

    .experience-card-content {
        padding: 28px;
    }

    .experience-card-content small {
        display: block;
        margin-bottom: 9px;
        color: var(--red);
        font-size: 11px;
        font-weight: 800;
        letter-spacing: 1.4px;
        text-transform: uppercase;
    }

    .experience-card-content h3 {
        margin: 0 0 12px;
        color: var(--green-dark);
        font-size: 24px;
        line-height: 1.25;
    }

    .experience-card-content p {
        margin: 0;
        color: var(--muted);
        font-size: 14px;
        line-height: 1.8;
    }

    .experience-quote {
        margin-top: 18px;
        padding: 14px 16px;
        border-left: 3px solid var(--red);
        border-radius: 0 5px 5px 0;
        background: var(--red-soft);
        color: #63323a;
        font-size: 13px;
        line-height: 1.7;
    }


    /* =========================================================
       FAQ
    ========================================================= */

    .faq-list {
        display: grid;
        gap: 10px;
    }

    .faq-item {
        overflow: hidden;
        border: 1px solid var(--line);
        border-radius: 6px;
        background: #fff;
    }

    .faq-question {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 15px;
        padding: 19px 20px;
        border: 0;
        background: transparent;
        color: var(--green-dark);
        font-weight: 700;
        text-align: left;
        cursor: pointer;
    }

    .faq-question i {
        transition: transform .25s ease;
    }

    .faq-answer {
        display: none;
        padding: 0 20px 20px;
        color: var(--muted);
        font-size: 14px;
        line-height: 1.75;
    }

    .faq-item.open .faq-answer {
        display: block;
    }

    .faq-item.open .faq-question i {
        transform: rotate(180deg);
    }


    /* =========================================================
       CTA
    ========================================================= */

    .magang-cta {
        padding: 50px;
        border-radius: 10px;
        background: var(--red);
        color: #fff;
        text-align: center;
    }

    .magang-cta h3 {
        margin: 0 0 12px;
        font-size: 33px;
    }

    .magang-cta p {
        max-width: 650px;
        margin: auto;
        color: rgba(255,255,255,.83);
        line-height: 1.75;
    }

    .magang-cta-button {
        display: inline-flex;
        margin-top: 24px;
        padding: 13px 22px;
        border: 0;
        border-radius: 5px;
        background: #fff;
        color: var(--red);
        font-size: 14px;
        font-weight: 800;
        cursor: pointer;
    }


    /* =========================================================
       KEGIATAN
    ========================================================= */

    .kegiatan-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
    }

    .kegiatan-card {
        padding: 32px;
        border: 1px solid var(--line);
        border-radius: 8px;
        background: #fff;
    }

    .kegiatan-card .number {
        color: var(--red);
        font-size: 12px;
        font-weight: 800;
        letter-spacing: 1.3px;
    }

    .kegiatan-card h3 {
        margin: 10px 0;
        color: var(--green-dark);
        font-size: 24px;
    }

    .kegiatan-card p {
        margin: 0;
        color: var(--muted);
        line-height: 1.8;
    }


    /* =========================================================
       TEORI
    ========================================================= */

    .teori-list {
        display: grid;
        gap: 18px;
    }

    .teori-item {
        display: grid;
        grid-template-columns: 75px 1fr;
        gap: 22px;
        padding: 28px;
        border: 1px solid var(--line);
        border-radius: 8px;
        background: #fff;
    }

    .teori-number {
        width: 55px;
        height: 55px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        background: var(--green-soft);
        color: var(--green);
        font-weight: 800;
    }

    .teori-item h3 {
        margin: 0 0 8px;
        color: var(--green-dark);
    }

    .teori-item p {
        margin: 0;
        color: var(--muted);
        line-height: 1.8;
    }


    /* =========================================================
       RESPONSIVE
    ========================================================= */

    @media (max-width: 900px) {

        .materi-grid,
        .jurusan-grid,
        .benefit-grid {
            grid-template-columns: repeat(2, 1fr);
        }

        .jurusan-detail-inner {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 650px) {

        .edu-container {
            width: min(100% - 28px, 1180px);
        }

        .edu-hero {
            padding: 60px 0;
        }

        .edu-intro-box {
            grid-template-columns: 1fr;
        }

        .materi-grid,
        .jurusan-grid,
        .benefit-grid,
        .kegiatan-grid {
            grid-template-columns: 1fr;
        }

        .materi-card {
            min-height: 250px;
        }

        .magang-hero {
            padding: 35px 25px;
        }

        .magang-cta {
            padding: 38px 24px;
        }

        .magang-cta h3 {
            font-size: 27px;
        }

        .teori-item {
            grid-template-columns: 1fr;
        }

        .experience-controls {
            justify-content: flex-start;
        }

        .experience-card {
            flex: 0 0 88%;
        }

        .experience-card-image {
            height: 230px;
        }

        .experience-card-content {
            padding: 23px;
        }

        .experience-card-content h3 {
            font-size: 21px;
        }
    }
</style>


<div class="edu-page">

    {{-- =====================================================
         HERO
    ====================================================== --}}
    <section class="edu-hero">

        <div class="edu-container">

            <div class="edu-hero-content">

                <span class="edu-eyebrow">
                    Avengers Team
                </span>

                <h1>
                    Edukasi Umum
                </h1>

                <p>
                    Ruang pembelajaran untuk mengenal dunia kerja,
                    kegiatan profesional, serta pengetahuan umum
                    yang berkaitan dengan dunia perdagangan berjangka.
                </p>

            </div>

        </div>

    </section>


    {{-- =====================================================
         3 MATERI UTAMA
    ====================================================== --}}
    <section
        class="materi-section"
        id="materiUtama"
    >

        <div class="edu-container">

            <div class="materi-grid">

                {{-- MAGANG --}}
                <div
                    class="materi-card"
                    onclick="bukaMateri('magang')"
                >
                    <h3>
                        Program Magang
                    </h3>

                    <p>
                        Mengenal pengalaman magang, jurusan yang relevan,
                        serta gambaran kegiatan pembelajaran di lingkungan
                        profesional.
                    </p>

                    <span class="materi-arrow">
                        <i class="bi bi-arrow-right"></i>
                    </span>

                </div>


                {{-- KEGIATAN --}}
                <div
                    class="materi-card"
                    onclick="bukaMateri('kegiatan')"
                >


                    <h3>
                        Kegiatan
                    </h3>

                    <p>
                        Mengenal berbagai kegiatan internal dan sosial
                        yang menjadi bagian dari proses pengembangan
                        diri dan kebersamaan.
                    </p>

                    <span class="materi-arrow">
                        <i class="bi bi-arrow-right"></i>
                    </span>

                </div>


                {{-- TEORI UMUM --}}
                <div
                    class="materi-card"
                    onclick="bukaMateri('teori')"
                >

                    {{-- 03 DIHAPUS SESUAI PERMINTAAN --}}

                    <h3>
                        Teori Umum
                    </h3>

                    <p>
                        Materi dasar mengenai komunikasi profesional
                        dan pengenalan dunia perdagangan.
                    </p>

                    <span class="materi-arrow">
                        <i class="bi bi-arrow-right"></i>
                    </span>

                </div>

            </div>

        </div>

    </section>


    {{-- =====================================================
         DETAIL PROGRAM MAGANG
    ====================================================== --}}
    <section
        class="materi-detail"
        id="detail-magang"
    >

        <div class="edu-container">

            <button
                type="button"
                class="back-materi"
                onclick="tutupMateri()"
            >
                <i class="bi bi-arrow-left"></i>
                Kembali ke Materi
            </button>


            <div class="magang-hero">

                <div class="magang-hero-content">

                    <small>
                        Program Magang
                    </small>

                    <h2>
                        Kenali Dunia Kerja
                        Lewat Pengalaman Magang
                    </h2>

                    <p>
                        Program magang menjadi kesempatan bagi mahasiswa
                        untuk mengenal lingkungan kerja secara langsung,
                        menerapkan pengetahuan yang telah dipelajari,
                        serta mengembangkan pengalaman profesional.
                    </p>

                    <button
                        type="button"
                        class="magang-explore"
                        onclick="scrollKeJurusan()"
                    >
                        Lihat Jurusan yang Relevan
                        <i class="bi bi-arrow-down"></i>
                    </button>

                </div>

            </div>


            {{-- =================================================
                 MANFAAT
            ================================================== --}}
            <div class="magang-section">

                <div class="magang-section-title">

                
                    <h3>
                        Belajar Tidak Hanya dari Ruang Kelas
                    </h3>

                    <p>
                        Pengalaman magang dapat menjadi kesempatan
                        untuk mengenal budaya kerja, membangun
                        keterampilan, dan memahami penerapan ilmu
                        dalam lingkungan profesional.
                    </p>

                </div>


                <div class="benefit-grid">

                    <div class="benefit-card">
                        <div class="benefit-icon">
                            <i class="bi bi-lightbulb"></i>
                        </div>

                        <h4>
                            Menambah Wawasan
                        </h4>

                        <p>
                            Mengenal bagaimana ilmu yang dipelajari
                            dapat diterapkan dalam lingkungan kerja.
                        </p>
                    </div>


                    <div class="benefit-card">
                        <div class="benefit-icon">
                            <i class="bi bi-person-workspace"></i>
                        </div>

                        <h4>
                            Mengenal Dunia Kerja
                        </h4>

                        <p>
                            Memahami suasana kerja dan cara berinteraksi
                            secara profesional.
                        </p>
                    </div>


                    <div class="benefit-card">
                        <div class="benefit-icon">
                            <i class="bi bi-people"></i>
                        </div>

                        <h4>
                            Mengembangkan Komunikasi
                        </h4>

                        <p>
                            Melatih kemampuan berkomunikasi dan
                            bekerja bersama orang lain.
                        </p>
                    </div>


                    <div class="benefit-card">
                        <div class="benefit-icon">
                            <i class="bi bi-journal-check"></i>
                        </div>

                        <h4>
                            Menerapkan Pengetahuan
                        </h4>

                        <p>
                            Menghubungkan materi perkuliahan dengan
                            pengalaman yang diperoleh selama kegiatan.
                        </p>
                    </div>


                    <div class="benefit-card">
                        <div class="benefit-icon">
                            <i class="bi bi-graph-up-arrow"></i>
                        </div>

                        <h4>
                            Mengembangkan Diri
                        </h4>

                        <p>
                            Membangun kebiasaan kerja dan tanggung jawab
                            dalam lingkungan profesional.
                        </p>
                    </div>


                    <div class="benefit-card">
                        <div class="benefit-icon">
                            <i class="bi bi-folder2-open"></i>
                        </div>

                        <h4>
                            Menambah Pengalaman
                        </h4>

                        <p>
                            Memiliki pengalaman yang dapat menjadi bagian
                            dari perjalanan akademik dan profesional.
                        </p>
                    </div>

                </div>

            </div>


            {{-- =================================================
                 JURUSAN + FOTO
            ================================================== --}}
            <div
                class="magang-section"
                id="jurusanMagang"
            >

                <div class="magang-section-title">

                

                    <h3>
                        Jurusan yang Relevan
                    </h3>

                    <p>
                        Beberapa latar belakang pendidikan memiliki
                        keterkaitan dengan aktivitas dan pembelajaran
                        yang dapat dikenalkan dalam lingkungan
                        PT Rifan Financindo Berjangka Semarang.
                    </p>

                </div>


                <div class="jurusan-grid">

                    {{-- MANAJEMEN --}}
                    <div
                        class="jurusan-card"
                        onclick="bukaJurusan('manajemen')"
                    >

                        <div class="jurusan-image">
                            <img
                                src="{{ asset('images/magang-manajemen.jpg') }}"
                                alt="Manajemen"
                            >
                        </div>

                        <div class="jurusan-content">                       

                            <h4>
                                Manajemen
                            </h4>

                            <p>
                                Mengenal pengelolaan kegiatan
                                dan proses bisnis.
                            </p>

                        </div>

                    </div>


                    {{-- AKUNTANSI --}}
                    <div
                        class="jurusan-card"
                        onclick="bukaJurusan('akuntansi')"
                    >

                        <div class="jurusan-image">
                            <img
                                src="{{ asset('images/magang-akuntansi.jpg') }}"
                                alt="Akuntansi"
                            >
                        </div>

                        <div class="jurusan-content">

                            <h4>
                                Akuntansi
                            </h4>

                            <p>
                                Mengenal administrasi dan informasi
                                keuangan dalam organisasi.
                            </p>

                        </div>

                    </div>


                    {{-- EKONOMI --}}
                    <div
                        class="jurusan-card"
                        onclick="bukaJurusan('ekonomi')"
                    >

                        <div class="jurusan-image">
                            <img
                                src="{{ asset('images/magang-ekonomi.jpg') }}"
                                alt="Ekonomi"
                            >
                        </div>

                        <div class="jurusan-content">

                            <h4>
                                Ekonomi
                            </h4>

                            <p>
                                Mengenal aktivitas ekonomi dan
                                dinamika pasar.
                            </p>

                        </div>

                    </div>


                    {{-- BISNIS --}}
                    <div
                        class="jurusan-card"
                        onclick="bukaJurusan('bisnis')"
                    >

                        <div class="jurusan-image">
                            <img
                                src="{{ asset('images/magang-bisnis.jpg') }}"
                                alt="Bisnis dan Administrasi"
                            >
                        </div>

                        <div class="jurusan-content">

                            <h4>
                                Bisnis & Administrasi
                            </h4>

                            <p>
                                Mengenal proses administrasi
                                dan kegiatan bisnis.
                            </p>

                        </div>

                    </div>


                    {{-- KOMUNIKASI --}}
                    <div
                        class="jurusan-card"
                        onclick="bukaJurusan('komunikasi')"
                    >

                        <div class="jurusan-image">
                            <img
                                src="{{ asset('images/magang-komunikasi.jpg') }}"
                                alt="Ilmu Komunikasi"
                            >
                        </div>

                        <div class="jurusan-content">

                            <h4>
                                Ilmu Komunikasi
                            </h4>

                            <p>
                                Mengembangkan komunikasi
                                dalam lingkungan profesional.
                            </p>

                        </div>

                    </div>


                    {{-- TEKNOLOGI --}}
                    <div
                        class="jurusan-card"
                        onclick="bukaJurusan('teknologi')"
                    >

                        <div class="jurusan-image">
                            <img
                                src="{{ asset('images/magang-teknologi.jpg') }}"
                                alt="Teknologi Informasi"
                            >
                        </div>

                        <div class="jurusan-content">

                            <h4>
                                Teknologi Informasi
                            </h4>

                            <p>
                                Mengenal pemanfaatan teknologi
                                untuk mendukung kegiatan perusahaan.
                            </p>

                        </div>

                    </div>

                </div>


                {{-- DETAIL JURUSAN --}}
                <div
                    class="jurusan-detail"
                    id="detail-manajemen"
                >

                    <div class="jurusan-detail-inner">

                        <div class="jurusan-detail-image">
                            <img
                                src="{{ asset('images/magang-manajemen.jpg') }}"
                                alt="Manajemen"
                            >
                        </div>

                        <div>

                            <small>
                                Jurusan yang Relevan
                            </small>

                            <h4>
                                Manajemen
                            </h4>

                            <p>
                                Mahasiswa Manajemen dapat mengenal
                                bagaimana sebuah organisasi menjalankan
                                kegiatan bisnis, mengelola proses kerja,
                                membangun hubungan dengan pihak lain,
                                serta memahami penerapan konsep manajemen
                                dalam lingkungan profesional.
                            </p>

                            <button
                                type="button"
                                class="close-jurusan"
                                onclick="tutupJurusan('manajemen')"
                            >
                                Tutup Detail
                            </button>

                        </div>

                    </div>

                </div>


                <div
                    class="jurusan-detail"
                    id="detail-akuntansi"
                >

                    <div class="jurusan-detail-inner">

                        <div class="jurusan-detail-image">
                            <img
                                src="{{ asset('images/magang-akuntansi.jpg') }}"
                                alt="Akuntansi"
                            >
                        </div>

                        <div>

                            <small>
                                Jurusan yang Relevan
                            </small>

                            <h4>
                                Akuntansi
                            </h4>

                            <p>
                                Mahasiswa Akuntansi dapat mengenal
                                proses administrasi, pencatatan,
                                pengelolaan informasi, dan pentingnya
                                ketelitian dalam lingkungan perusahaan.
                            </p>

                            <button
                                type="button"
                                class="close-jurusan"
                                onclick="tutupJurusan('akuntansi')"
                            >
                                Tutup Detail
                            </button>

                        </div>

                    </div>

                </div>


                <div
                    class="jurusan-detail"
                    id="detail-ekonomi"
                >

                    <div class="jurusan-detail-inner">

                        <div class="jurusan-detail-image">
                            <img
                                src="{{ asset('images/magang-ekonomi.jpg') }}"
                                alt="Ekonomi"
                            >
                        </div>

                        <div>

                            <small>
                                Jurusan yang Relevan
                            </small>

                            <h4>
                                Ekonomi
                            </h4>

                            <p>
                                Mahasiswa Ekonomi dapat mengenal
                                hubungan antara kegiatan ekonomi,
                                pasar, dan perkembangan perdagangan
                                melalui pembelajaran di lingkungan
                                profesional.
                            </p>

                            <button
                                type="button"
                                class="close-jurusan"
                                onclick="tutupJurusan('ekonomi')"
                            >
                                Tutup Detail
                            </button>

                        </div>

                    </div>

                </div>


                <div
                    class="jurusan-detail"
                    id="detail-bisnis"
                >

                    <div class="jurusan-detail-inner">

                        <div class="jurusan-detail-image">
                            <img
                                src="{{ asset('images/magang-bisnis.jpg') }}"
                                alt="Bisnis dan Administrasi"
                            >
                        </div>

                        <div>

                            <small>
                                Jurusan yang Relevan
                            </small>

                            <h4>
                                Bisnis & Administrasi
                            </h4>

                            <p>
                                Mahasiswa Bisnis dan Administrasi dapat
                                mengenal proses administrasi, komunikasi
                                internal, dan kegiatan bisnis perusahaan.
                            </p>

                            <button
                                type="button"
                                class="close-jurusan"
                                onclick="tutupJurusan('bisnis')"
                            >
                                Tutup Detail
                            </button>

                        </div>

                    </div>

                </div>


                <div
                    class="jurusan-detail"
                    id="detail-komunikasi"
                >

                    <div class="jurusan-detail-inner">

                        <div class="jurusan-detail-image">
                            <img
                                src="{{ asset('images/magang-komunikasi.jpg') }}"
                                alt="Ilmu Komunikasi"
                            >
                        </div>

                        <div>

                            <small>
                                Jurusan yang Relevan
                            </small>

                            <h4>
                                Ilmu Komunikasi
                            </h4>

                            <p>
                                Mahasiswa Ilmu Komunikasi dapat
                                mengembangkan kemampuan menyampaikan
                                informasi, membangun komunikasi profesional,
                                serta memahami pentingnya komunikasi
                                dalam lingkungan kerja.
                            </p>

                            <button
                                type="button"
                                class="close-jurusan"
                                onclick="tutupJurusan('komunikasi')"
                            >
                                Tutup Detail
                            </button>

                        </div>

                    </div>

                </div>


                <div
                    class="jurusan-detail"
                    id="detail-teknologi"
                >

                    <div class="jurusan-detail-inner">

                        <div class="jurusan-detail-image">
                            <img
                                src="{{ asset('images/magang-teknologi.jpg') }}"
                                alt="Teknologi Informasi"
                            >
                        </div>

                        <div>

                            <small>
                                Jurusan yang Relevan
                            </small>

                            <h4>
                                Teknologi Informasi
                            </h4>

                            <p>
                                Mahasiswa Teknologi Informasi dapat
                                mengenal bagaimana teknologi dan sistem
                                informasi dimanfaatkan untuk mendukung
                                kegiatan perusahaan.
                            </p>

                            <button
                                type="button"
                                class="close-jurusan"
                                onclick="tutupJurusan('teknologi')"
                            >
                                Tutup Detail
                            </button>

                        </div>

                    </div>

                </div>

            </div>


            {{-- =================================================
                 PENGALAMAN MAGANG + FOTO
            ================================================== --}}
            <div class="magang-section">

                <div class="magang-section-title">

                    <h3>
                        Bagaimana Pengalaman Magang di PT Rifan Financindo Berjangka Semarang?
                    </h3>

                    <p>
                        Cerita pengalaman mahasiswa selama mengenal
                        lingkungan kerja dan mengikuti kegiatan magang.
                    </p>

                </div>


                <div class="experience-slider">

                    <div class="experience-controls">

                        <button
                            type="button"
                            class="experience-control"
                            onclick="geserPengalaman(-1)"
                            aria-label="Pengalaman sebelumnya"
                        >
                            <i class="bi bi-arrow-left"></i>
                        </button>

                        <button
                            type="button"
                            class="experience-control"
                            onclick="geserPengalaman(1)"
                            aria-label="Pengalaman berikutnya"
                        >
                            <i class="bi bi-arrow-right"></i>
                        </button>

                    </div>


                    <div
                        class="experience-track"
                        id="experienceTrack"
                    >

                        {{-- PENGALAMAN 1 --}}
                        <article class="experience-card">

                            <div class="experience-card-image">

                                <img
                                    src="{{ asset('images/pengalaman-magang-1.jpg') }}"
                                    alt="Pengalaman Magang 1"
                                >

                            </div>

                            <div class="experience-card-content">

                                

                                <h3>
                                    Mengenal Lingkungan Kerja
                                </h3>

                                <p>
                                    Selama mengikuti kegiatan magang,
                                    mahasiswa dapat mengenal secara
                                    langsung bagaimana lingkungan kerja
                                    berjalan. Mulai dari beradaptasi,
                                    berkomunikasi, hingga memahami
                                    tanggung jawab dalam kegiatan.
                                </p>

                                <div class="experience-quote">
                                    “Setiap hari menjadi kesempatan
                                    untuk belajar sesuatu yang baru.”
                                </div>

                            </div>

                        </article>


                        {{-- PENGALAMAN 2 --}}
                        <article class="experience-card">

                            <div class="experience-card-image">

                                <img
                                    src="{{ asset('images/pengalaman-magang-2.jpg') }}"
                                    alt="Pengalaman Magang 2"
                                >

                            </div>

                            <div class="experience-card-content">

                                

                                <h3>
                                    Belajar dan Beradaptasi
                                </h3>

                                <p>
                                    Pengalaman magang memberikan
                                    kesempatan untuk belajar
                                    menyesuaikan diri dengan lingkungan
                                    baru, memahami pola kerja, serta
                                    mengembangkan sikap profesional.
                                </p>

                                <div class="experience-quote">
                                    “Belajar beradaptasi adalah bagian
                                    dari proses menjadi lebih siap.”
                                </div>

                            </div>

                        </article>


                        {{-- PENGALAMAN 3 --}}
                        <article class="experience-card">

                            <div class="experience-card-image">

                                <img
                                    src="{{ asset('images/pengalaman-magang-3.jpg') }}"
                                    alt="Pengalaman Magang 3"
                                >

                            </div>

                            <div class="experience-card-content">

                                

                                <h3>
                                    Mengembangkan Kemampuan
                                </h3>

                                <p>
                                    Melalui berbagai kegiatan, mahasiswa
                                    dapat mengembangkan kemampuan
                                    komunikasi, kerja sama, tanggung jawab,
                                    dan keterampilan pendukung lainnya.
                                </p>

                                <div class="experience-quote">
                                    “Pengalaman kecil hari ini dapat
                                    menjadi bekal untuk langkah berikutnya.”
                                </div>

                            </div>

                        </article>


                        {{-- PENGALAMAN 4 --}}
                        <article class="experience-card">

                            <div class="experience-card-image">

                                <img
                                    src="{{ asset('images/pengalaman-magang-4.jpg') }}"
                                    alt="Pengalaman Magang 4"
                                >

                            </div>

                            <div class="experience-card-content">

                                
                                <h3>
                                    Membangun Pengalaman
                                </h3>

                                <p>
                                    Setiap kegiatan selama magang dapat
                                    menjadi pengalaman yang membantu
                                    mahasiswa memahami bagaimana ilmu
                                    dan keterampilan diterapkan dalam
                                    lingkungan profesional.
                                </p>

                                <div class="experience-quote">
                                    “Pengalaman adalah bagian dari
                                    perjalanan untuk terus berkembang.”
                                </div>

                            </div>

                        </article>

                    </div>

                </div>

            </div>


            {{-- =================================================
                 FAQ
            ================================================== --}}
            <div class="magang-section">

                <div class="magang-section-title">

                    <h3>
                        FAQ Program Magang
                    </h3>

                </div>


                <div class="faq-list">

                    <div class="faq-item">

                        <button
                            type="button"
                            class="faq-question"
                            onclick="toggleFaq(this)"
                        >
                            <span>
                                Apa tujuan dari kegiatan magang?
                            </span>

                            <i class="bi bi-chevron-down"></i>
                        </button>

                        <div class="faq-answer">
                            Kegiatan magang memberikan kesempatan
                            kepada mahasiswa untuk mengenal lingkungan
                            kerja dan mendapatkan pengalaman yang
                            relevan dengan proses pembelajaran.
                        </div>

                    </div>


                    <div class="faq-item">

                        <button
                            type="button"
                            class="faq-question"
                            onclick="toggleFaq(this)"
                        >
                            <span>
                                Apakah semua jurusan dapat mengikuti?
                            </span>

                            <i class="bi bi-chevron-down"></i>
                        </button>

                        <div class="faq-answer">
                            Kesesuaian jurusan dapat disesuaikan dengan
                            kebutuhan kegiatan dan program yang tersedia.
                            Daftar di atas merupakan gambaran jurusan
                            yang relevan untuk konteks edukasi magang.
                        </div>

                    </div>


                    <div class="faq-item">

                        <button
                            type="button"
                            class="faq-question"
                            onclick="toggleFaq(this)"
                        >
                            <span>
                                Apa yang dapat dipelajari mahasiswa?
                            </span>

                            <i class="bi bi-chevron-down"></i>
                        </button>

                        <div class="faq-answer">
                            Mahasiswa dapat mengenal lingkungan
                            profesional, komunikasi kerja, kegiatan
                            administrasi, proses bisnis, serta berbagai
                            pengalaman yang sesuai dengan kegiatan magang.
                        </div>

                    </div>


                    <div class="faq-item">

                        <button
                            type="button"
                            class="faq-question"
                            onclick="toggleFaq(this)"
                        >
                            <span>
                                Apakah pengalaman setiap mahasiswa sama?
                            </span>

                            <i class="bi bi-chevron-down"></i>
                        </button>

                        <div class="faq-answer">
                            Pengalaman setiap mahasiswa dapat berbeda
                            tergantung jurusan, kegiatan, pendampingan,
                            dan aktivitas yang diikuti selama program.
                        </div>

                    </div>

                </div>

            </div>


            {{-- CTA --}}
            <div class="magang-cta">

                <h3>
                    Siap Memulai Langkahmu?
                </h3>

                <p>
                    Kenali lebih jauh pengalaman belajar dan dunia kerja
                    melalui program edukasi dan magang.
                </p>

                <button
                    type="button"
                    class="magang-cta-button"
                    onclick="scrollKeJurusan()"
                >
                    Lihat Jurusan
                </button>

            </div>

        </div>

    </section>


    {{-- =====================================================
         DETAIL KEGIATAN
    ====================================================== --}}
    <section
        class="materi-detail"
        id="detail-kegiatan"
    >

        <div class="edu-container">

            <button
                type="button"
                class="back-materi"
                onclick="tutupMateri()"
            >
                <i class="bi bi-arrow-left"></i>
                Kembali ke Materi
            </button>


            <div class="section-heading">

                <h2>
                    Kegiatan
                </h2>

                <p>
                    Berbagai kegiatan yang menjadi bagian dari proses
                    membangun pengalaman, kebersamaan, dan pengembangan
                    diri.
                </p>

            </div>


            <div class="kegiatan-grid">

                <div class="kegiatan-card">

                    <h3>
                        Kegiatan Internal
                    </h3>

                    <p>
                        Kegiatan internal menjadi ruang untuk membangun
                        komunikasi, kebersamaan, koordinasi, dan kerja
                        sama dalam lingkungan profesional.
                    </p>

                </div>


                <div class="kegiatan-card">

                    <h3>
                        Kegiatan Sosial
                    </h3>

                    <p>
                        Kegiatan sosial menjadi bagian dari upaya
                        membangun kepedulian dan hubungan yang baik
                        dengan lingkungan sekitar.
                    </p>

                </div>

            </div>

        </div>

    </section>


    {{-- =====================================================
         DETAIL TEORI
    ====================================================== --}}
    <section
        class="materi-detail"
        id="detail-teori"
    >

        <div class="edu-container">

            <button
                type="button"
                class="back-materi"
                onclick="tutupMateri()"
            >
                <i class="bi bi-arrow-left"></i>
                Kembali ke Materi
            </button>


            <div class="section-heading">

                <small>
                    Pengetahuan
                </small>

                <h2>
                    Teori Umum
                </h2>

                <p>
                    Materi dasar yang membantu memahami komunikasi
                    profesional dan pengenalan perdagangan.
                </p>

            </div>


            <div class="teori-list">

                <div class="teori-item">

                    <div class="teori-number">
                        01
                    </div>

                    <div>

                        <h3>
                            Komunikasi Profesional
                        </h3>

                        <p>
                            Komunikasi profesional merupakan kemampuan
                            menyampaikan informasi dengan jelas, sopan,
                            dan bertanggung jawab dalam lingkungan kerja.
                        </p>

                    </div>

                </div>


                <div class="teori-item">

                    <div class="teori-number">
                        02
                    </div>

                    <div>

                        <h3>
                            Pengenalan Perdagangan
                        </h3>

                        <p>
                            Pengenalan perdagangan memberikan gambaran
                            mengenai aktivitas perdagangan dan bagaimana
                            berbagai pihak berinteraksi dalam kegiatan
                            ekonomi.
                        </p>

                    </div>

                </div>

            </div>

        </div>

    </section>

</div>


<script>

    /* =========================================================
       BUKA MATERI
    ========================================================= */

    function bukaMateri(id) {

        const utama =
            document.getElementById('materiUtama');

        const semuaDetail =
            document.querySelectorAll('.materi-detail');

        utama.style.display = 'none';

        semuaDetail.forEach(function(detail) {
            detail.classList.remove('active');
        });

        const target =
            document.getElementById('detail-' + id);

        if (target) {
            target.classList.add('active');
        }

        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    }


    /* =========================================================
       TUTUP MATERI
    ========================================================= */

    function tutupMateri() {

        const utama =
            document.getElementById('materiUtama');

        const semuaDetail =
            document.querySelectorAll('.materi-detail');

        semuaDetail.forEach(function(detail) {
            detail.classList.remove('active');
        });

        utama.style.display = 'block';

        window.scrollTo({
            top: utama.offsetTop - 40,
            behavior: 'smooth'
        });
    }


    /* =========================================================
       BUKA DETAIL JURUSAN
    ========================================================= */

    function bukaJurusan(id) {

        const semuaDetail =
            document.querySelectorAll('.jurusan-detail');

        semuaDetail.forEach(function(detail) {
            detail.classList.remove('active');
        });

        const target =
            document.getElementById('detail-' + id);

        if (!target) {
            return;
        }

        target.classList.add('active');

        setTimeout(function() {

            target.scrollIntoView({
                behavior: 'smooth',
                block: 'center'
            });

        }, 50);
    }


    /* =========================================================
       TUTUP DETAIL JURUSAN
    ========================================================= */

    function tutupJurusan(id) {

        const target =
            document.getElementById('detail-' + id);

        if (target) {
            target.classList.remove('active');
        }
    }


    /* =========================================================
       SCROLL KE JURUSAN
    ========================================================= */

    function scrollKeJurusan() {

        const target =
            document.getElementById('jurusanMagang');

        if (!target) {
            return;
        }

        target.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }


    /* =========================================================
       SLIDER PENGALAMAN MAGANG
    ========================================================= */

    function geserPengalaman(arah) {

        const track =
            document.getElementById('experienceTrack');

        if (!track) {
            return;
        }

        const card =
            track.querySelector('.experience-card');

        if (!card) {
            return;
        }

        const jarak =
            card.offsetWidth + 22;

        track.scrollBy({
            left: jarak * arah,
            behavior: 'smooth'
        });
    }


    /* =========================================================
       FAQ
    ========================================================= */

    function toggleFaq(button) {

        const item =
            button.closest('.faq-item');

        if (!item) {
            return;
        }

        item.classList.toggle('open');
    }

</script>

@endsection